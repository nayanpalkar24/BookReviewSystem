package com.sample.demo;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.entity.Admin;
import com.repo.AdminRepo;
import com.service.AdminService;

import org.junit.runners.MethodSorters;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringRunner.class)
@SpringBootTest
public class AdminTest {
	
	@Autowired
	private AdminService adminService;
	
	@MockBean
	private AdminRepo adminRepo;
	

	@Test
	public void aAddAdminTest() {
		Admin admin = new Admin();                         //successful
		admin.setEmail("admin@gmail.com");
		admin.setAname("Admin");
		admin.setPassword("Admin@123");
		
		when(adminRepo.hasAdmin(admin.getEmail())).thenReturn(0);
		when(adminRepo.save(admin)).thenReturn(admin);
		
		boolean isAdded = adminService.addAdmin(admin);
		assertTrue(isAdded);
	}
	
	@Test
	public void bAddAdminTest() {
		Admin admin = new Admin();                         //failed
		admin.setEmail("admin@gmail.com");
		admin.setAname("Admin");
		admin.setPassword("Admin@123");
		
		when(adminRepo.hasAdmin(admin.getEmail())).thenReturn(1);
		
		boolean isAdded = adminService.addAdmin(admin);
		assertFalse(isAdded);
	}
	
	@Test
	public void cUpdateAdminTest()
	{
		Admin admin = new Admin();
		admin.setEmail("admin@gmail.com");                             //successfull
		admin.setAname("Admin");
		admin.setPassword("Admin@123");
		
		when(adminRepo.save(admin)).thenReturn(admin);
		
		boolean isAdded  = adminService.updateAdmin(admin);
		assertTrue(isAdded);
	}
	
	@Test
	public void dValidAdminLoginTest()                                                                      //successful
	{
		
		when(adminRepo.validateLogin("admin@gmail.com", "Admin@123")).thenReturn(null);
		
		boolean isAuthenticated  = adminService.validateAdmin("admin@gmail.com", "Admin@123");
		assertTrue(isAuthenticated);
	}
	
	@Test
	public void eValidAdminLoginTest()
	{
		
		when(adminRepo.validateLogin("admin@gmail.com", "Admin@123")).thenReturn(null);
		
		boolean isAuthenticated  = adminService.validateAdmin("admin@gmail.com", "Admin@123");
		assertFalse(isAuthenticated);                                                                       //failed
	}
	
	

	
	
	

}
